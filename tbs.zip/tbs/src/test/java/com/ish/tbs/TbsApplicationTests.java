package com.ish.tbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
