package com.ish.tbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TbsApplication.class, args);
	}

}
